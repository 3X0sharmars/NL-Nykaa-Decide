import os
import json
import re
import time
import requests
from datetime import datetime, timezone
from dotenv import load_dotenv
from flask import Flask, render_template, jsonify, request
from google_play_scraper import reviews, Sort

load_dotenv()

app = Flask(__name__)

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_API_URL = (
    "https://generativelanguage.googleapis.com"
    "/v1beta/models/gemini-2.0-flash:generateContent"
)

REVIEW_KEYWORDS = [
    "toys", "beauty", "personal care", "books", "electronics",
    "fashion", "sports", "baby", "pet", "pharmacy", "medicine",
    "explore", "discover", "new category", "never knew",
    "only groceries", "just groceries", "more than grocery",
    "amazon", "firstcry", "nykaa", "myntra", "flipkart",
    "variety", "selection", "trust", "quality", "range",
    "habit", "always order", "never tried", "didn't realize",
]

RESEARCH_QUERIES = [
    "Why do Indian Blinkit users only buy groceries and ignore categories like toys beauty electronics fashion?",
    "Why do Indian parents switch to Amazon FirstCry Nykaa instead of buying toys baby care on Blinkit?",
    "What prevents quick commerce users in India from exploring new product categories on Blinkit?",
    "What would make Indian users trust Blinkit for non-grocery categories like electronics fashion toys?",
    "Which non-grocery categories do Indian Blinkit users mention most as unmet needs or switching reasons?",
    "How do shopping habits affect category exploration behavior on quick commerce apps in India?",
]


def call_gemini(prompt_text):
    headers = {
        "Content-Type": "application/json",
    }
    params = {
        "key": GEMINI_API_KEY,
    }
    payload = {
        "contents": [{
            "parts": [{
                "text": prompt_text,
            }],
        }],
        "generationConfig": {
            "temperature": 0.3,
            "maxOutputTokens": 1000,
        },
    }

    response = requests.post(
        GEMINI_API_URL,
        headers=headers,
        params=params,
        json=payload,
        timeout=60,
    )

    if response.status_code != 200:
        raise Exception(
            f"Gemini API error {response.status_code}: {response.text}"
        )

    data = response.json()
    return data["candidates"][0]["content"]["parts"][0]["text"]


def collect_gemini_data():
    results = []

    for query in RESEARCH_QUERIES:
        prompt = (
            "You are a product research analyst with knowledge of Indian "
            "consumer behavior and quick commerce platforms. Based on your "
            "knowledge, provide detailed insights about: " + query +
            " Focus on Blinkit specifically. Include specific behavioral "
            "patterns, user quotes if known, and concrete examples from "
            "Indian market context."
        )
        try:
            content = call_gemini(prompt)
            results.append(f"=== {query} ===\n{content}")
        except Exception as e:
            results.append(f"=== {query} ===\nError: {e}")
        time.sleep(2)

    return "\n\n".join(results)


def fetch_play_store_reviews():
    try:
        result_reviews, _ = reviews(
            "com.grofers.customerapp",
            lang="en",
            country="in",
            sort=Sort.NEWEST,
            count=200,
        )
    except Exception as e:
        return f"Play Store fetch failed: {e}", 0

    filtered = []
    for r in result_reviews:
        text = (r.get("content") or "").lower()
        if any(kw in text for kw in REVIEW_KEYWORDS):
            rating = r.get("score", "N/A")
            date = r.get("at", "N/A")
            thumbs = r.get("thumbsUpCount", 0)
            review_text = r.get("content", "")
            filtered.append(
                f"Rating: {rating} | Date: {date} | ThumbsUp: {thumbs}\n{review_text}"
            )

    count = len(filtered)
    header = f"Filtered Play Store Reviews ({count} of {len(result_reviews)}):\n"
    body = "\n---\n".join(filtered)
    return header + body, count


def run_analysis(raw_data):
    url = "https://integrate.api.nvidia.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {os.getenv('NVIDIA_API_KEY')}",
        "Content-Type": "application/json"
    }

    analysis_prompt = (
        "You are a senior product research analyst specializing in "
        "Indian quick commerce consumer behavior. "
        "Respond ONLY with pure valid JSON. "
        "No markdown. No backticks. No explanation. Pure JSON only.\n\n"
        "Analyze this data about Blinkit user behavior.\n\n"
        "Return exactly this JSON structure:\n"
        "{\n"
        '  "questions": [\n'
        '    {\n'
        '      "id": "Q1",\n'
        '      "question": "...",\n'
        '      "answer": "2-3 sentence answer",\n'
        '      "evidence": ["specific example 1", "specific example 2"],\n'
        '      "confidence_score": "High",\n'
        '      "confidence_explanation": "one line"\n'
        '    }\n'
        "  ],\n"
        '  "themes": [\n'
        '    {\n'
        '      "name": "...",\n'
        '      "frequency": "High",\n'
        '      "description": "one line"\n'
        '    }\n'
        "  ],\n"
        '  "segments": ["segment1", "segment2"],\n'
        '  "failure_analysis": [\n'
        '    {\n'
        '      "case": "where data was insufficient",\n'
        '      "resolution": "what research would help"\n'
        '    }\n'
        "  ],\n"
        '  "validation_gaps": ["gap1", "gap2", "gap3", "gap4"]\n'
        "}\n\n"
        "Answer these 5 research questions with evidence:\n"
        "Q1: Why do frequent Blinkit users buy only groceries "
        "despite Beauty Personal Care Books Electronics "
        "Fashion Sports Toys being available?\n"
        "Q2: What triggers switching to Amazon FirstCry "
        "Nykaa Myntra instead of exploring Blinkit?\n"
        "Q3: What would build trust for non-grocery "
        "categories on Blinkit?\n"
        "Q4: Have users expanded beyond grocery on Blinkit? "
        "What changed their behavior?\n"
        "Q5: Which non-grocery categories are most mentioned "
        "as unmet needs on Blinkit?\n\n"
        "Include exactly 5 questions, 5 themes, "
        "3 failure analysis cases, 4 validation gaps.\n\n"
        "RAW DATA:\n" + raw_data[:5000]
    )

    payload = {
        "model": "meta/llama-3.1-70b-instruct",
        "messages": [
            {
                "role": "system",
                "content": "You are a product research analyst. Always respond with pure valid JSON only. No markdown, no backticks, no explanation."
            },
            {
                "role": "user",
                "content": analysis_prompt
            }
        ],
        "temperature": 0.2,
        "max_tokens": 2000
    }

    response = requests.post(
        url,
        headers=headers,
        json=payload,
        timeout=60
    )
    response.raise_for_status()
    data = response.json()
    content = data["choices"][0]["message"]["content"]

    # Clean any markdown if model adds it
    content = content.strip()
    if content.startswith("```"):
        content = re.sub(r"^```(?:json)?\s*", "", content)
        content = re.sub(r"\s*```$", "", content)

    return json.loads(content)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/collect", methods=["POST"])
def collect():
    try:
        gemini_data = collect_gemini_data()
        play_data, ps_count = fetch_play_store_reviews()

        raw_data = f"GEMINI RESEARCH:\n{gemini_data}\n\nPLAY STORE REVIEWS:\n{play_data}"

        return jsonify({
            "status": "success",
            "raw_data": raw_data,
            "meta": {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "research_queries": len(RESEARCH_QUERIES),
                "play_store_reviews": ps_count,
                "total_chars": len(raw_data),
            },
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e),
        })


@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        raw_data = request.json.get("raw_data", "")

        if not raw_data:
            gemini_data = collect_gemini_data()
            play_data, ps_count = fetch_play_store_reviews()
            raw_data = f"GEMINI RESEARCH:\n{gemini_data}\n\nPLAY STORE REVIEWS:\n{play_data}"
        else:
            ps_count = raw_data.count("\n---\n") + 1

        analysis = run_analysis(raw_data)

        return jsonify({
            "status": "success",
            "data": analysis,
            "meta": {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "research_queries": len(RESEARCH_QUERIES),
                "play_store_reviews": ps_count,
                "total_chars": len(raw_data),
            },
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e),
        })


if __name__ == "__main__":
    app.run(port=5000, debug=True)
